
# --------------------------------------------------------------------
# log any 'abnormal' terminations
# --------------------------------------------------------------------
$DefaultPartition core_log ${global_param} ${swsa_pkg_param} ${core_log_param}

# --------------------------------------------------------------------
# DMA driver
# --------------------------------------------------------------------
#$DefaultPartition mx31_dma_cfg ${global_param} ${swsa_pkg_param} ${mx31_dma_cfg_param:--c}

# --------------------------------------------------------------------
# I2C driver
# --------------------------------------------------------------------
# For video encoder and iPod authentication 
$DefaultPartition i2c-imx31_swsa ${global_param} ${swsa_pkg_param} ${i2c_imx31_swsa_1_param:--I1 --u0} &
# For Touch Screen and TMC
$DefaultPartition i2c-imx31_swsa ${global_param} ${swsa_pkg_param} ${i2c_imx31_swsa_2_param:--I2 --u1} &

# --------------------------------------------------------------------
# USB Fault Detection
# --------------------------------------------------------------------
# For detecting a short circuit on a USB device 
$DefaultPartition usb-fault ${global_param} ${swsa_pkg_param} ${usb_fault_param} &

# --------------------------------------------------------------------
# SPI driver
# --------------------------------------------------------------------
spi-master ${global_param} ${swsa_pkg_param} ${spi_master_param:--u0 -d /lib/dll/spi-imx31_swsa.so base=0x50010000} &

# --------------------------------------------------------------------
# Audio control
# --------------------------------------------------------------------
$DefaultPartition wm8580a-control-manager ${global_param} ${swsa_pkg_param} ${wm8580a_control_manager_param} &
$DefaultPartition wm8580a-control ${global_param} ${swsa_pkg_param} ${wm8580a_control_param:--G} &
# Temporary until startup problems resolved.
waitfor /dev/xxx 2 2>/dev/null

# --------------------------------------------------------------------
# Audio driver
# --------------------------------------------------------------------
# documentation says do NOT start multiple instances of io-audio
$apsAudio io-audio ${global_param} ${swsa_pkg_param} ${io_audio_param:--osw_mixer_samples=2048 -d stereo.so -osw_mixer_samples=3072 -d mono.so} &
#$apsAudio io-audio -d stereo.so -d mono.so &

# --------------------------------------------------------------------
# Reversing Camera
# --------------------------------------------------------------------
if [ X"$boardVariant" != X"low" ]
then
    $DefaultPartition reversing-camera ${global_param} ${swsa_pkg_param} ${reversing_camera_param:--l1 -x40 -O} &
fi

# --------------------------------------------------------------------
# Power Script (used for executing scripts based on 
#               power mode transitions)
# --------------------------------------------------------------------
#$apsDebug powerScript ${global_param} ${swsa_pkg_param} ${powerScript_param:--n /dev/swsa/power_script -p "etfs/powerScript" -S "/etc/clean_fs_usb.sh"} & 

