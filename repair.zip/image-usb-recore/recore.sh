/fs/usb0/repair.ino.elf
