
cd /packages
mx31_dma_cfg -c
SD.ino.elf disk name=sd blk cache=2m,auto=partition,automount=sd0@dos:/fs/sd0,rw dos exe=all
cd /
waitfor /fs/sd0 20
sleep 6

