
$DefaultPartition pmm ${global_param} ${power_pkg_param} ${pmm_param:--B 600 -I -D 2000} &
