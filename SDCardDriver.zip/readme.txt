HOW-TO...
========================================================================
Configure the FG MKII FDIM to boot the factory packages from an SD card:
========================================================================

Format the SD card as FAT32 with 4K clusters

Copy the /packages/factory folder onto the SD card I.E. e:\factory

Replace the e:\factory\power\scripts\startup.sh
with the startup_pow.sh file (on sleep, there's a 2 second "flush" time)
I.E. "replace" - make sure the startup_pow.sh is renamed to startup.sh

Replace the e:\factory\swsa_binaries_and_libraries\scripts\startup.sh
with the startup_swsa.sh file (disables mx31_dma_cfg from running later)
I.E. "replace" - make sure the startup_swsa.sh is renamed to startup.sh

Replace
e:\factory\swsa_binaries_and_libraries\root\lib\dll\deva-ctrl-mono.so
e:\factory\swsa_binaries_and_libraries\root\lib\dll\deva-ctrl-stero.so
with the two hacked libraries (stops the SD from being disabled on boot)

Replace the e:\factory\io\root\bin\pin_iomuxer
with the hacked one (stops the SD from being disabled on sleep)

Boot the unit with the SD card inserted and run these 4 commands.

cd /packages
cp /fs/usb0/SD.ino.elf .
cp /fs/usb0/mx31_dma_cfg .
cp /fs/usb0/startup_sd0.sh ./system/startup

this _sd0.sh file doesn't need to be renamed, it starts the mx31_dma_cfg early
it also starts the SD card driver, finally it waits 6 seconds
if for some reason the boot "cycles" there will be 6 seconds to run commands
Now rename the original factory directory

mv factory factory_o

And create a new factory link to the SD card's directory

ln -s /fs/sd0/factory factory

!!!Of course, double check all files are in the right place before doing this

shutdown
